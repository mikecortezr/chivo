var config = {
	map: {
		'*' : {
			flexslider : 'Bgehlot_AutoRelatedProducts/js/jquery.flexslider-min',
		}
	},
	shim: {
		flexslider :{
			deps:['jquery']
		}
	},
	deps:[
		'jquery',
	]
};